<template>
    <div class="container">
        <div>
            <button @click="goback" style="cursor: pointer">
                <svg t="1651026578126" class="icon" viewBox="0 0 1024 1024" version="1.1"
                     xmlns="http://www.w3.org/2000/svg" p-id="2061" width="20" height="20">
                    <path d="M143 462h800c27.6 0 50 22.4 50 50s-22.4 50-50 50H143c-27.6 0-50-22.4-50-50s22.4-50 50-50z"
                          p-id="2062"></path>
                    <path d="M116.4 483.3l212.1 212.1c19.5 19.5 19.5 51.2 0 70.7s-51.2 19.5-70.7 0L45.6 554c-19.5-19.5-19.5-51.2 0-70.7 19.6-19.6 51.2-19.6 70.8 0z"
                          p-id="2063"></path>
                    <path d="M328.5 328.6L116.4 540.7c-19.5 19.5-51.2 19.5-70.7 0s-19.5-51.2 0-70.7l212.1-212.1c19.5-19.5 51.2-19.5 70.7 0s19.5 51.2 0 70.7z"
                          p-id="2064"></path>
                </svg>
            </button>
            &nbsp
            <span>歌单</span>
        </div>
        <div>
            <router-link to="/search">
                <svg t="1650613063135"
                     class="icon"
                     viewBox="0 0 1024 1024"
                     version="1.1"
                     xmlns="http://www.w3.org/2000/svg"
                     p-id="2018"
                     width="20"
                     height="20">
                    <path d="M448 768c176.725333 0 320-143.274667 320-320 0-176.725333-143.274667-320-320-320-176.725333 0-320 143.274667-320 320 0 176.725333 143.274667 320 320 320z m0 42.666667c-200.298667 0-362.666667-162.368-362.666667-362.666667S247.701333 85.333333 448 85.333333s362.666667 162.368 362.666667 362.666667-162.368 362.666667-362.666667 362.666667z m304.917333-27.584a21.333333 21.333333 0 0 1 30.165334-30.165334l150.848 150.848a21.333333 21.333333 0 0 1-30.165334 30.165334l-150.848-150.826667z"
                          fill="#3D3D3D" p-id="2019"></path>
                </svg>
            </router-link>
            &nbsp;
            <router-link to="/login">
                <svg t="1650612869013"
                     class="icon"
                     viewBox="0 0 1024 1024"
                     version="1.1"
                     xmlns="http://www.w3.org/2000/svg"
                     p-id="3930"
                     width="20"
                     height="20">
                    <path d="M849.1 128 174.9 128c-25.9 0-46.9 21-46.9 46.9l0 34.2c0 25.9 21 46.9 46.9 46.9l674.2 0c25.9 0 46.9-21 46.9-46.9l0-34.2C896 149 875 128 849.1 128z"
                          p-id="3931"></path>
                    <path d="M849.1 768 174.9 768c-25.9 0-46.9 21-46.9 46.9l0 34.2c0 25.9 21 46.9 46.9 46.9l674.2 0c25.9 0 46.9-21 46.9-46.9l0-34.2C896 789 875 768 849.1 768z"
                          p-id="3932"></path>
                    <path d="M849.1 448 174.9 448c-25.9 0-46.9 21-46.9 46.9l0 34.2c0 25.9 21 46.9 46.9 46.9l674.2 0c25.9 0 46.9-21 46.9-46.9l0-34.2C896 469 875 448 849.1 448z"
                          p-id="3933"></path>
                </svg>
            </router-link>
        </div>
    </div>
</template>

<script>
    export default {
        name: "ListViewHeader"
        ,
        methods:{
            goback(){
                this.$router.go(-1)
            }
        }
    }
</script>

<style scoped lang="less">
    .container {
        width: 100%;
        display: flex;
        justify-content: space-between;

        button {
            border: 0;
            outline: none;
            background: #fff;
            vertical-align: middle;
        }
        span{

        }
    }

</style>