<template>
    <!--    使用组件-->
    <router-view/>
</template>
<script>
    // 引入组件
    export default {
        name: 'App',
        components: {
        }
    }
</script>
<style lang="less">//css高级形式

</style>
