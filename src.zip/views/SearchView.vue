<template>
    <h2>搜索</h2>
</template>

<script>
    export default {
        name: "SearchView"
    }
</script>

<style scoped>

</style>