<template>
    <h2>登陆页面</h2>
</template>

<script>
    export default {
        name: "LoginView"
    }
</script>

<style scoped>

</style>