<template>
    <HeaderCom/>
    <h2>视频</h2>
</template>

<script>
    import HeaderCom from "@/components/header/HeaderCom";
    export default {
        name: "VideoView",
        components: {
            HeaderCom
        }
    }
</script>

<style scoped>

</style>