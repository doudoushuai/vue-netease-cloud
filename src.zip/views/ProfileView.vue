<template>
    <HeaderCom/>
    <h2>Profile</h2>
</template>

<script>
    import HeaderCom from "@/components/header/HeaderCom";
    export default {
        name: "ProfileView",
        components: {
            HeaderCom
        }
    }
</script>

<style scoped>

</style>