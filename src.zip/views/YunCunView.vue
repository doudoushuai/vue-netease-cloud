<template>
    <HeaderCom/>
    <h1>云村</h1>
</template>

<script>
    import HeaderCom from "@/components/header/HeaderCom";
    export default {
        name: "YueCunView",
        components: {
            HeaderCom
        }
    }
</script>

<style scoped>

</style>